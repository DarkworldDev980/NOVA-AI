import type { Express, Request, Response } from "express";
import { createServer, type Server } from "node:http";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

interface ChatRequest {
  messages: ChatMessage[];
}

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/chat", async (req: Request, res: Response) => {
    try {
      const { messages } = req.body as ChatRequest;

      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Messages array is required" });
      }

      const systemMessage: ChatMessage = {
        role: "system",
        content: `أنت NOVA AI، مساعد ذكي ودود. تتحدث العربية والإنجليزية بطلاقة. تساعد المستخدمين في الإجابة على أسئلتهم وحل مشاكلهم بطريقة واضحة ومفيدة. كن موجزاً ومفيداً.

You are NOVA AI, a friendly and intelligent assistant. You speak Arabic and English fluently. You help users answer their questions and solve their problems in a clear and helpful way. Be concise and helpful.`
      };

      const fullMessages = [systemMessage, ...messages];

      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: fullMessages,
        max_completion_tokens: 2048,
      });

      const assistantMessage = response.choices?.[0]?.message?.content || "عذراً، لم أتمكن من إنشاء رد.";

      return res.json({
        message: assistantMessage,
        usage: response.usage,
      });
    } catch (error) {
      console.error("Chat API error:", error);
      return res.status(500).json({ error: "حدث خطأ في معالجة طلبك. حاول مرة أخرى." });
    }
  });

  app.get("/api/health", (_req: Request, res: Response) => {
    return res.json({ status: "ok", service: "NOVA AI" });
  });

  const httpServer = createServer(app);

  return httpServer;
}
