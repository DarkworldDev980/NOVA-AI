import React from "react";
import { View, StyleSheet, ActivityIndicator } from "react-native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { HeaderButton } from "@react-navigation/elements";
import { Feather } from "@expo/vector-icons";

import NovaChatScreen from "@/screens/NovaChatScreen";
import SettingsScreen from "@/screens/SettingsScreen";
import LoginScreen from "@/screens/LoginScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/contexts/AuthContext";
import { Colors } from "@/constants/theme";

export type RootStackParamList = {
  Login: undefined;
  NovaChat: undefined;
  Settings: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

function NovaHeaderTitle() {
  return (
    <View style={styles.headerTitle}>
      <View style={[styles.novaIcon, { backgroundColor: Colors.dark.primary }]}>
        <Feather name="cpu" size={14} color="#FFFFFF" />
      </View>
    </View>
  );
}

export default function RootStackNavigator() {
  const screenOptions = useScreenOptions();
  const { theme } = useTheme();
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.backgroundRoot }]}>
        <ActivityIndicator size="large" color={Colors.dark.primary} />
      </View>
    );
  }

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      {user ? (
        <>
          <Stack.Screen
            name="NovaChat"
            component={NovaChatScreen}
            options={({ navigation }) => ({
              headerTitle: () => <NovaHeaderTitle />,
              headerLeft: () => (
                <HeaderButton onPress={() => navigation.navigate("Settings")}>
                  <Feather name="settings" size={22} color={theme.text} />
                </HeaderButton>
              ),
              headerRight: () => (
                <HeaderButton onPress={() => {}}>
                  <Feather name="plus-circle" size={22} color={theme.text} />
                </HeaderButton>
              ),
            })}
          />
          <Stack.Screen
            name="Settings"
            component={SettingsScreen}
            options={{
              headerTitle: "الإعدادات",
              headerBackTitle: "رجوع",
            }}
          />
        </>
      ) : (
        <Stack.Screen
          name="Login"
          component={LoginScreen}
          options={{ headerShown: false }}
        />
      )}
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  headerTitle: {
    flexDirection: "row",
    alignItems: "center",
  },
  novaIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});
