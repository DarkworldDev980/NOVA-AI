import { createClient } from "@supabase/supabase-js";
import AsyncStorage from "@react-native-async-storage/async-storage";

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || "https://wmkkqnuvzsazurswdjdr.supabase.co";
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Indta2txbnV2enNhenVyc3dkamRyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk0Mzc4MzAsImV4cCI6MjA4NTAxMzgzMH0.PRVzT4kIOiWftiQN8uZt2OFgeX-jJg56xO7xHfzqCss";
const edgeFunctionUrl = process.env.EXPO_PUBLIC_EDGE_FUNCTION_URL || "https://wmkkqnuvzsazurswdjdr.supabase.co/functions/v1/clever-handler";

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

export const EDGE_FUNCTION_URL = edgeFunctionUrl;
export const SUPABASE_ANON_KEY = supabaseAnonKey;

export type Profile = {
  id: string;
  email?: string;
  phone?: string;
  display_name: string;
  avatar_url?: string;
  is_online: boolean;
  last_seen: string;
  created_at: string;
};

export type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  created_at: string;
};

export type Conversation = {
  id: string;
  title: string;
  messages: Message[];
  created_at: string;
  updated_at: string;
};
