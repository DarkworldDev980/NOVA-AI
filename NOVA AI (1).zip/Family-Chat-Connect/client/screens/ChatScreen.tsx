import React, { useState, useRef, useCallback, useEffect } from "react";
import {
  View,
  StyleSheet,
  FlatList,
  TextInput,
  Pressable,
  Image,
  Platform,
  ListRenderItem,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import { useRoute, RouteProp } from "@react-navigation/native";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, { FadeIn, FadeInUp } from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/contexts/AuthContext";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";
import { Message } from "@/lib/supabase";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type ChatScreenRouteProp = RouteProp<RootStackParamList, "Chat">;

const generateMockMessages = (conversationId: string): Message[] => {
  const now = Date.now();
  return [
    {
      id: "m1",
      conversation_id: conversationId,
      sender_id: "other",
      content: "Hey! How are you doing?",
      type: "text",
      created_at: new Date(now - 1000 * 60 * 60).toISOString(),
    },
    {
      id: "m2",
      conversation_id: conversationId,
      sender_id: "me",
      content: "I'm great, thanks! Just finished work.",
      type: "text",
      created_at: new Date(now - 1000 * 60 * 55).toISOString(),
    },
    {
      id: "m3",
      conversation_id: conversationId,
      sender_id: "other",
      content: "That's wonderful! Are you coming to dinner on Sunday?",
      type: "text",
      created_at: new Date(now - 1000 * 60 * 50).toISOString(),
    },
    {
      id: "m4",
      conversation_id: conversationId,
      sender_id: "me",
      content: "Yes, of course! I wouldn't miss it.",
      type: "text",
      created_at: new Date(now - 1000 * 60 * 45).toISOString(),
    },
    {
      id: "m5",
      conversation_id: conversationId,
      sender_id: "other",
      content: "Perfect! See you then!",
      type: "text",
      created_at: new Date(now - 1000 * 60 * 40).toISOString(),
    },
  ];
};

export default function ChatScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const route = useRoute<ChatScreenRouteProp>();
  const { theme, isDark } = useTheme();
  const { user } = useAuth();

  const { conversationId } = route.params;
  
  const [messages, setMessages] = useState<Message[]>(() => 
    generateMockMessages(conversationId)
  );
  const [inputText, setInputText] = useState("");
  const flatListRef = useRef<FlatList>(null);

  const sendMessage = useCallback(() => {
    if (!inputText.trim()) return;

    const newMessage: Message = {
      id: `m${Date.now()}`,
      conversation_id: conversationId,
      sender_id: "me",
      content: inputText.trim(),
      type: "text",
      created_at: new Date().toISOString(),
    };

    setMessages(prev => [newMessage, ...prev]);
    setInputText("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }, [inputText, conversationId]);

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  const isMyMessage = (senderId: string) => senderId === "me";

  const renderMessage: ListRenderItem<Message> = useCallback(({ item, index }) => {
    const isMine = isMyMessage(item.sender_id);
    const showAvatar = !isMine && (index === messages.length - 1 || isMyMessage(messages[index + 1]?.sender_id));

    return (
      <Animated.View 
        entering={FadeInUp.delay(index * 20).duration(200)}
        style={[
          styles.messageRow,
          isMine ? styles.messageRowRight : styles.messageRowLeft,
        ]}
      >
        {!isMine && showAvatar ? (
          <View style={[styles.messageAvatar, { backgroundColor: Colors.light.primary + "20" }]}>
            <ThemedText style={[styles.avatarText, { color: Colors.light.primary }]}>
              {route.params.name?.charAt(0).toUpperCase()}
            </ThemedText>
          </View>
        ) : !isMine ? (
          <View style={styles.avatarPlaceholder} />
        ) : null}

        <View style={[
          styles.messageBubble,
          isMine 
            ? [styles.messageBubbleRight, { backgroundColor: Colors.light.primary }]
            : [styles.messageBubbleLeft, { backgroundColor: isDark ? theme.backgroundSecondary : theme.backgroundDefault }]
        ]}>
          <ThemedText style={[
            styles.messageText,
            { color: isMine ? "#FFFFFF" : theme.text }
          ]}>
            {item.content}
          </ThemedText>
          <ThemedText style={[
            styles.messageTime,
            { color: isMine ? "rgba(255,255,255,0.7)" : theme.textTertiary }
          ]}>
            {formatTime(item.created_at)}
          </ThemedText>
        </View>
      </Animated.View>
    );
  }, [messages, theme, isDark, route.params.name]);

  const renderEmptyState = () => (
    <View style={styles.emptyContainer}>
      <Feather name="message-circle" size={48} color={theme.textTertiary} />
      <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
        No messages yet. Start the conversation!
      </ThemedText>
    </View>
  );

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      behavior="padding"
      keyboardVerticalOffset={0}
    >
      <FlatList
        ref={flatListRef}
        data={messages}
        renderItem={renderMessage}
        keyExtractor={(item) => item.id}
        inverted={messages.length > 0}
        contentContainerStyle={[
          styles.listContent,
          { paddingTop: headerHeight + Spacing.md }
        ]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={renderEmptyState}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="interactive"
      />

      <View style={[
        styles.inputContainer,
        { 
          backgroundColor: theme.backgroundDefault,
          paddingBottom: insets.bottom + Spacing.sm,
          borderTopColor: theme.border,
        }
      ]}>
        <Pressable style={styles.attachButton}>
          <Feather name="plus" size={22} color={theme.textSecondary} />
        </Pressable>

        <View style={[styles.textInputContainer, { backgroundColor: theme.backgroundSecondary }]}>
          <TextInput
            style={[styles.textInput, { color: theme.text }]}
            placeholder="Type a message..."
            placeholderTextColor={theme.textTertiary}
            value={inputText}
            onChangeText={setInputText}
            multiline
            maxLength={1000}
            testID="input-message"
          />
        </View>

        <Pressable
          style={[
            styles.sendButton,
            { backgroundColor: inputText.trim() ? Colors.light.primary : theme.backgroundSecondary }
          ]}
          onPress={sendMessage}
          disabled={!inputText.trim()}
          testID="button-send"
        >
          <Feather 
            name="send" 
            size={18} 
            color={inputText.trim() ? "#FFFFFF" : theme.textTertiary} 
          />
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listContent: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
    flexGrow: 1,
  },
  messageRow: {
    flexDirection: "row",
    marginVertical: Spacing.xs,
    alignItems: "flex-end",
  },
  messageRowLeft: {
    justifyContent: "flex-start",
  },
  messageRowRight: {
    justifyContent: "flex-end",
  },
  messageAvatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.xs,
  },
  avatarText: {
    fontSize: 12,
    fontWeight: "600",
  },
  avatarPlaceholder: {
    width: 28,
    marginRight: Spacing.xs,
  },
  messageBubble: {
    maxWidth: "75%",
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.lg,
  },
  messageBubbleLeft: {
    borderBottomLeftRadius: BorderRadius.xs,
  },
  messageBubbleRight: {
    borderBottomRightRadius: BorderRadius.xs,
  },
  messageText: {
    fontSize: 15,
    lineHeight: 20,
  },
  messageTime: {
    fontSize: 11,
    marginTop: Spacing.xs,
    alignSelf: "flex-end",
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing["5xl"],
    transform: [{ scaleY: -1 }],
  },
  emptyText: {
    marginTop: Spacing.md,
    textAlign: "center",
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "flex-end",
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.sm,
    borderTopWidth: 1,
  },
  attachButton: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  textInputContainer: {
    flex: 1,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    marginHorizontal: Spacing.xs,
    maxHeight: 120,
  },
  textInput: {
    fontSize: 16,
    lineHeight: 20,
    minHeight: 24,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
});
