import React, { useState } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  Image,
  Alert,
  ActivityIndicator,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { Card } from "@/components/Card";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/contexts/AuthContext";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";

interface SettingItem {
  id: string;
  icon: keyof typeof Feather.glyphMap;
  title: string;
  subtitle?: string;
  onPress: () => void;
  showArrow?: boolean;
  danger?: boolean;
}

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();
  const { profile, user, signOut } = useAuth();

  const [loggingOut, setLoggingOut] = useState(false);

  const handleLogout = async () => {
    Alert.alert(
      "Sign Out",
      "Are you sure you want to sign out?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Sign Out",
          style: "destructive",
          onPress: async () => {
            setLoggingOut(true);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            await signOut();
            setLoggingOut(false);
          },
        },
      ]
    );
  };

  const settingsSections: { title: string; items: SettingItem[] }[] = [
    {
      title: "Settings",
      items: [
        {
          id: "notifications",
          icon: "bell",
          title: "Notifications",
          subtitle: "Manage notification preferences",
          onPress: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light),
          showArrow: true,
        },
        {
          id: "privacy",
          icon: "shield",
          title: "Privacy",
          subtitle: "Control who can see your info",
          onPress: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light),
          showArrow: true,
        },
        {
          id: "theme",
          icon: "moon",
          title: "Appearance",
          subtitle: "Dark mode, colors",
          onPress: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light),
          showArrow: true,
        },
        {
          id: "language",
          icon: "globe",
          title: "Language",
          subtitle: "English",
          onPress: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light),
          showArrow: true,
        },
      ],
    },
    {
      title: "Support",
      items: [
        {
          id: "help",
          icon: "help-circle",
          title: "Help Center",
          onPress: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light),
          showArrow: true,
        },
        {
          id: "feedback",
          icon: "message-square",
          title: "Send Feedback",
          onPress: () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light),
          showArrow: true,
        },
      ],
    },
    {
      title: "Account",
      items: [
        {
          id: "logout",
          icon: "log-out",
          title: "Sign Out",
          onPress: handleLogout,
          danger: true,
        },
      ],
    },
  ];

  const renderSettingItem = (item: SettingItem) => (
    <Pressable
      key={item.id}
      style={({ pressed }) => [
        styles.settingItem,
        { backgroundColor: pressed ? theme.backgroundSecondary : "transparent" }
      ]}
      onPress={item.onPress}
      testID={`setting-${item.id}`}
    >
      <View style={[
        styles.settingIcon,
        { backgroundColor: item.danger ? Colors.light.error + "20" : Colors.light.primary + "15" }
      ]}>
        <Feather 
          name={item.icon} 
          size={18} 
          color={item.danger ? Colors.light.error : Colors.light.primary} 
        />
      </View>
      <View style={styles.settingContent}>
        <ThemedText style={[styles.settingTitle, item.danger && { color: Colors.light.error }]}>
          {item.title}
        </ThemedText>
        {item.subtitle ? (
          <ThemedText style={[styles.settingSubtitle, { color: theme.textSecondary }]}>
            {item.subtitle}
          </ThemedText>
        ) : null}
      </View>
      {item.showArrow ? (
        <Feather name="chevron-right" size={20} color={theme.textTertiary} />
      ) : null}
    </Pressable>
  );

  if (loggingOut) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.backgroundRoot }]}>
        <ActivityIndicator size="large" color={Colors.light.primary} />
        <ThemedText style={{ marginTop: Spacing.lg }}>Signing out...</ThemedText>
      </View>
    );
  }

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={[
        styles.content,
        {
          paddingTop: headerHeight + Spacing.xl,
          paddingBottom: tabBarHeight + Spacing.xl,
        }
      ]}
      showsVerticalScrollIndicator={false}
    >
      <Pressable
        style={[styles.profileCard, { backgroundColor: theme.backgroundDefault }]}
        onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)}
        testID="profile-card"
      >
        <View style={styles.profileAvatarContainer}>
          {profile?.avatar_url ? (
            <Image source={{ uri: profile.avatar_url }} style={styles.profileAvatar} />
          ) : (
            <View style={[styles.profileAvatarPlaceholder, { backgroundColor: Colors.light.primary }]}>
              <ThemedText style={styles.profileAvatarText}>
                {profile?.display_name?.charAt(0).toUpperCase() || "U"}
              </ThemedText>
            </View>
          )}
          <Pressable style={[styles.editAvatarButton, { backgroundColor: theme.backgroundDefault }]}>
            <Feather name="camera" size={14} color={theme.text} />
          </Pressable>
        </View>

        <View style={styles.profileInfo}>
          <ThemedText type="h2">{profile?.display_name || "User"}</ThemedText>
          <ThemedText style={[styles.profileEmail, { color: theme.textSecondary }]}>
            {user?.email || profile?.phone || "No email"}
          </ThemedText>
        </View>

        <View style={styles.editProfileContainer}>
          <Feather name="edit-2" size={16} color={Colors.light.primary} />
          <ThemedText style={[styles.editProfileText, { color: Colors.light.primary }]}>
            Edit Profile
          </ThemedText>
        </View>
      </Pressable>

      {settingsSections.map((section, index) => (
        <View key={section.title} style={styles.section}>
          <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
            {section.title}
          </ThemedText>
          <View style={[styles.sectionContent, { backgroundColor: theme.backgroundDefault }]}>
            {section.items.map((item, itemIndex) => (
              <View key={item.id}>
                {renderSettingItem(item)}
                {itemIndex < section.items.length - 1 ? (
                  <View style={[styles.separator, { backgroundColor: theme.border }]} />
                ) : null}
              </View>
            ))}
          </View>
        </View>
      ))}

      <ThemedText style={[styles.version, { color: theme.textTertiary }]}>
        Family Chat v1.0.0
      </ThemedText>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  profileCard: {
    borderRadius: BorderRadius.lg,
    padding: Spacing.xl,
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  profileAvatarContainer: {
    position: "relative",
    marginBottom: Spacing.lg,
  },
  profileAvatar: {
    width: 88,
    height: 88,
    borderRadius: 44,
  },
  profileAvatarPlaceholder: {
    width: 88,
    height: 88,
    borderRadius: 44,
    alignItems: "center",
    justifyContent: "center",
  },
  profileAvatarText: {
    fontSize: 32,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  editAvatarButton: {
    position: "absolute",
    bottom: 0,
    right: 0,
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#FFFFFF",
  },
  profileInfo: {
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  profileEmail: {
    fontSize: 14,
    marginTop: Spacing.xs,
  },
  editProfileContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  editProfileText: {
    fontSize: 14,
    fontWeight: "500",
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: "600",
    textTransform: "uppercase",
    marginBottom: Spacing.sm,
    marginLeft: Spacing.sm,
  },
  sectionContent: {
    borderRadius: BorderRadius.md,
    overflow: "hidden",
  },
  settingItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.md,
  },
  settingIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
  },
  settingSubtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  separator: {
    height: 1,
    marginLeft: 60,
  },
  version: {
    textAlign: "center",
    fontSize: 12,
    marginTop: Spacing.lg,
  },
});
