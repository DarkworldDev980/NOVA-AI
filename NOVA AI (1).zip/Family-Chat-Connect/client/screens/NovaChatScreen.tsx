import React, { useState, useRef, useCallback } from "react";
import {
  View,
  StyleSheet,
  FlatList,
  TextInput,
  Pressable,
  ActivityIndicator,
  ListRenderItem,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { KeyboardAvoidingView } from "react-native-keyboard-controller";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, { FadeIn, FadeInUp } from "react-native-reanimated";
import { LinearGradient } from "expo-linear-gradient";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors, CosmicGradient, Shadows } from "@/constants/theme";
import { Message, EDGE_FUNCTION_URL, SUPABASE_ANON_KEY } from "@/lib/supabase";
import { useAuth } from "@/contexts/AuthContext";

const SUGGESTED_PROMPTS = [
  "ما هي قدراتك؟",
  "Tell me a joke",
  "اشرح لي الذكاء الاصطناعي",
  "Help me write an email",
];

export default function NovaChatScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme, isDark } = useTheme();
  const { user } = useAuth();

  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const flatListRef = useRef<FlatList>(null);

  const sendMessage = useCallback(async (text?: string) => {
    const messageText = text || inputText.trim();
    if (!messageText || isLoading) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      content: messageText,
      created_at: new Date().toISOString(),
    };

    setMessages(prev => [userMessage, ...prev]);
    setInputText("");
    setIsLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    try {
      const conversationHistory = [...messages, userMessage]
        .reverse()
        .map(m => ({ role: m.role, content: m.content }));

      const response = await fetch(EDGE_FUNCTION_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${SUPABASE_ANON_KEY}`,
          "apikey": SUPABASE_ANON_KEY,
        },
        body: JSON.stringify({
          messages: conversationHistory,
          user_id: user?.id || "anonymous",
        }),
      });

      const data = await response.json();

      if (response.ok) {
        const assistantContent = data.message || data.response || data.content || data.text || 
          (typeof data === "string" ? data : JSON.stringify(data));
        
        const assistantMessage: Message = {
          id: `assistant-${Date.now()}`,
          role: "assistant",
          content: assistantContent,
          created_at: new Date().toISOString(),
        };
        setMessages(prev => [assistantMessage, ...prev]);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } else {
        const errorMessage: Message = {
          id: `error-${Date.now()}`,
          role: "assistant",
          content: data.error || "عذراً، حدث خطأ. حاول مرة أخرى.",
          created_at: new Date().toISOString(),
        };
        setMessages(prev => [errorMessage, ...prev]);
      }
    } catch (error) {
      console.error("Chat error:", error);
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        role: "assistant",
        content: "عذراً، لا يمكن الاتصال بالخادم. تحقق من اتصالك بالإنترنت.",
        created_at: new Date().toISOString(),
      };
      setMessages(prev => [errorMessage, ...prev]);
    } finally {
      setIsLoading(false);
    }
  }, [inputText, messages, isLoading, user]);

  const clearChat = useCallback(() => {
    setMessages([]);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  }, []);

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  const renderMessage: ListRenderItem<Message> = useCallback(({ item, index }) => {
    const isUser = item.role === "user";

    return (
      <Animated.View 
        entering={FadeInUp.delay(index * 30).duration(250)}
        style={[
          styles.messageRow,
          isUser ? styles.messageRowRight : styles.messageRowLeft,
        ]}
      >
        {!isUser && (
          <View style={[styles.novaAvatar, { backgroundColor: Colors.dark.primary }]}>
            <Feather name="cpu" size={14} color="#FFFFFF" />
          </View>
        )}

        <View style={[
          styles.messageBubble,
          isUser 
            ? [styles.messageBubbleUser, { backgroundColor: Colors.dark.primary }]
            : [styles.messageBubbleNova, { 
                backgroundColor: isDark ? "rgba(30, 27, 75, 0.9)" : "rgba(255, 255, 255, 0.95)",
                borderLeftColor: Colors.dark.primary,
              }]
        ]}>
          <ThemedText style={[
            styles.messageText,
            { color: isUser ? "#FFFFFF" : theme.text }
          ]}>
            {item.content}
          </ThemedText>
          <ThemedText style={[
            styles.messageTime,
            { color: isUser ? "rgba(255,255,255,0.7)" : theme.textTertiary }
          ]}>
            {formatTime(item.created_at)}
          </ThemedText>
        </View>
      </Animated.View>
    );
  }, [theme, isDark]);

  const renderEmptyState = () => (
    <View style={styles.emptyContainer}>
      <Animated.View 
        entering={FadeIn.delay(100).duration(400)}
        style={styles.welcomeCard}
      >
        <LinearGradient
          colors={["rgba(139, 92, 246, 0.2)", "rgba(59, 130, 246, 0.1)"]}
          style={styles.welcomeGradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <View style={[styles.novaLogo, { backgroundColor: Colors.dark.primary }]}>
            <Feather name="cpu" size={32} color="#FFFFFF" />
          </View>
          <ThemedText style={[styles.welcomeTitle, { color: theme.text }]}>
            مرحباً بك في NOVA AI
          </ThemedText>
          <ThemedText style={[styles.welcomeSubtitle, { color: theme.textSecondary }]}>
            أنا مساعدك الذكي. كيف يمكنني مساعدتك اليوم؟
          </ThemedText>

          <View style={styles.promptsContainer}>
            {SUGGESTED_PROMPTS.map((prompt, index) => (
              <Pressable
                key={index}
                style={[styles.promptChip, { 
                  backgroundColor: isDark ? "rgba(139, 92, 246, 0.2)" : "rgba(139, 92, 246, 0.1)",
                  borderColor: Colors.dark.primary + "40",
                }]}
                onPress={() => sendMessage(prompt)}
              >
                <ThemedText style={[styles.promptText, { color: Colors.dark.primary }]}>
                  {prompt}
                </ThemedText>
              </Pressable>
            ))}
          </View>
        </LinearGradient>
      </Animated.View>
    </View>
  );

  return (
    <LinearGradient
      colors={CosmicGradient.colors as [string, string, ...string[]]}
      style={styles.container}
      start={CosmicGradient.start}
      end={CosmicGradient.end}
    >
      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior="padding"
        keyboardVerticalOffset={0}
      >
        <FlatList
          ref={flatListRef}
          data={messages}
          renderItem={renderMessage}
          keyExtractor={(item) => item.id}
          inverted={messages.length > 0}
          contentContainerStyle={[
            styles.listContent,
            { paddingTop: headerHeight + Spacing.md }
          ]}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={renderEmptyState}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="interactive"
        />

        {isLoading && (
          <View style={styles.typingIndicator}>
            <View style={[styles.novaAvatar, { backgroundColor: Colors.dark.primary }]}>
              <Feather name="cpu" size={14} color="#FFFFFF" />
            </View>
            <View style={[styles.typingBubble, { backgroundColor: isDark ? "rgba(30, 27, 75, 0.9)" : "rgba(255, 255, 255, 0.95)" }]}>
              <ActivityIndicator size="small" color={Colors.dark.primary} />
              <ThemedText style={[styles.typingText, { color: theme.textSecondary }]}>
                NOVA يكتب...
              </ThemedText>
            </View>
          </View>
        )}

        <View style={[
          styles.inputContainer,
          { 
            paddingBottom: insets.bottom + Spacing.sm,
          }
        ]}>
          <View style={[
            styles.inputWrapper,
            { 
              backgroundColor: isDark ? "rgba(30, 27, 75, 0.8)" : "rgba(255, 255, 255, 0.95)",
              ...Shadows.glow,
            }
          ]}>
            <TextInput
              style={[styles.textInput, { color: theme.text }]}
              placeholder="اكتب رسالتك هنا..."
              placeholderTextColor={theme.textTertiary}
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={2000}
              testID="input-message"
              editable={!isLoading}
            />

            <Pressable
              style={[
                styles.sendButton,
                { 
                  backgroundColor: inputText.trim() && !isLoading 
                    ? Colors.dark.primary 
                    : "rgba(139, 92, 246, 0.3)" 
                }
              ]}
              onPress={() => sendMessage()}
              disabled={!inputText.trim() || isLoading}
              testID="button-send"
            >
              <Feather 
                name="send" 
                size={18} 
                color={inputText.trim() && !isLoading ? "#FFFFFF" : "rgba(255,255,255,0.5)"} 
              />
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  listContent: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
    flexGrow: 1,
  },
  messageRow: {
    flexDirection: "row",
    marginVertical: Spacing.xs,
    alignItems: "flex-end",
  },
  messageRowLeft: {
    justifyContent: "flex-start",
  },
  messageRowRight: {
    justifyContent: "flex-end",
  },
  novaAvatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.xs,
  },
  messageBubble: {
    maxWidth: "80%",
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.lg,
  },
  messageBubbleUser: {
    borderBottomRightRadius: BorderRadius.xs,
  },
  messageBubbleNova: {
    borderBottomLeftRadius: BorderRadius.xs,
    borderLeftWidth: 2,
  },
  messageText: {
    fontSize: 15,
    lineHeight: 22,
  },
  messageTime: {
    fontSize: 11,
    marginTop: Spacing.xs,
    alignSelf: "flex-end",
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing["5xl"],
    transform: [{ scaleY: -1 }],
  },
  welcomeCard: {
    width: "100%",
    maxWidth: 340,
  },
  welcomeGradient: {
    borderRadius: BorderRadius.xl,
    padding: Spacing.xl,
    alignItems: "center",
  },
  novaLogo: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.lg,
  },
  welcomeTitle: {
    fontSize: 22,
    fontWeight: "700",
    marginBottom: Spacing.sm,
    textAlign: "center",
  },
  welcomeSubtitle: {
    fontSize: 15,
    textAlign: "center",
    marginBottom: Spacing.xl,
  },
  promptsContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    gap: Spacing.sm,
  },
  promptChip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  promptText: {
    fontSize: 13,
    fontWeight: "500",
  },
  typingIndicator: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
  },
  typingBubble: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.lg,
    gap: Spacing.sm,
  },
  typingText: {
    fontSize: 13,
  },
  inputContainer: {
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.sm,
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "flex-end",
    borderRadius: BorderRadius.xl,
    paddingLeft: Spacing.lg,
    paddingRight: Spacing.sm,
    paddingVertical: Spacing.sm,
  },
  textInput: {
    flex: 1,
    fontSize: 16,
    lineHeight: 22,
    minHeight: 24,
    maxHeight: 100,
    paddingVertical: Spacing.xs,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    marginLeft: Spacing.sm,
  },
});
