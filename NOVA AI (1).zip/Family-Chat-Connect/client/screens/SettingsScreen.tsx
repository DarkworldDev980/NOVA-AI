import React, { useState } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Pressable,
  Switch,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/contexts/AuthContext";
import { Spacing, BorderRadius, Colors, CosmicGradient } from "@/constants/theme";

interface SettingItemProps {
  icon: keyof typeof Feather.glyphMap;
  title: string;
  subtitle?: string;
  value?: boolean;
  onValueChange?: (value: boolean) => void;
  onPress?: () => void;
  showArrow?: boolean;
}

function SettingItem({ icon, title, subtitle, value, onValueChange, onPress, showArrow }: SettingItemProps) {
  const { theme } = useTheme();

  return (
    <Pressable 
      style={[styles.settingItem, { backgroundColor: "rgba(30, 27, 75, 0.6)" }]}
      onPress={onPress}
      disabled={!onPress && !onValueChange}
    >
      <View style={[styles.settingIcon, { backgroundColor: Colors.dark.primary + "30" }]}>
        <Feather name={icon} size={18} color={Colors.dark.primary} />
      </View>
      <View style={styles.settingContent}>
        <ThemedText style={[styles.settingTitle, { color: theme.text }]}>
          {title}
        </ThemedText>
        {subtitle ? (
          <ThemedText style={[styles.settingSubtitle, { color: theme.textSecondary }]}>
            {subtitle}
          </ThemedText>
        ) : null}
      </View>
      {onValueChange ? (
        <Switch
          value={value}
          onValueChange={(v) => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            onValueChange(v);
          }}
          trackColor={{ false: "rgba(139, 92, 246, 0.2)", true: Colors.dark.primary }}
          thumbColor="#FFFFFF"
        />
      ) : showArrow ? (
        <Feather name="chevron-right" size={20} color={theme.textTertiary} />
      ) : null}
    </Pressable>
  );
}

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const { theme, isDark, toggleTheme } = useTheme();
  const { user, signOut } = useAuth();

  const [notifications, setNotifications] = useState(true);

  const handleSignOut = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Alert.alert(
      "تسجيل الخروج",
      "هل أنت متأكد من رغبتك في تسجيل الخروج؟",
      [
        { text: "إلغاء", style: "cancel" },
        { text: "تسجيل الخروج", style: "destructive", onPress: signOut },
      ]
    );
  };

  return (
    <LinearGradient
      colors={CosmicGradient.colors as [string, string, ...string[]]}
      style={styles.container}
      start={CosmicGradient.start}
      end={CosmicGradient.end}
    >
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.content,
          { 
            paddingTop: headerHeight + Spacing.xl,
            paddingBottom: insets.bottom + Spacing.xl,
          }
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.profileCard}>
          <View style={[styles.avatarContainer, { backgroundColor: Colors.dark.primary }]}>
            <Feather name="user" size={40} color="#FFFFFF" />
          </View>
          <ThemedText style={[styles.appName, { color: theme.text }]}>
            {user?.displayName || "المستخدم"}
          </ThemedText>
          <ThemedText style={[styles.appTagline, { color: theme.textSecondary }]}>
            {user?.email || ""}
          </ThemedText>
        </View>

        <View style={styles.section}>
          <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
            الإعدادات
          </ThemedText>
          
          <SettingItem
            icon="moon"
            title="الوضع الداكن"
            subtitle="تفعيل المظهر الداكن"
            value={isDark}
            onValueChange={toggleTheme}
          />
          
          <SettingItem
            icon="bell"
            title="الإشعارات"
            subtitle="تلقي إشعارات التطبيق"
            value={notifications}
            onValueChange={setNotifications}
          />
        </View>

        <View style={styles.section}>
          <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
            حول التطبيق
          </ThemedText>
          
          <SettingItem
            icon="info"
            title="الإصدار"
            subtitle="1.0.0"
          />
          
          <SettingItem
            icon="shield"
            title="سياسة الخصوصية"
            showArrow
            onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)}
          />
          
          <SettingItem
            icon="file-text"
            title="شروط الاستخدام"
            showArrow
            onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)}
          />
        </View>

        <View style={styles.section}>
          <ThemedText style={[styles.sectionTitle, { color: theme.textSecondary }]}>
            الحساب
          </ThemedText>
          
          <Pressable
            style={[styles.signOutButton, { backgroundColor: "rgba(239, 68, 68, 0.2)" }]}
            onPress={handleSignOut}
          >
            <Feather name="log-out" size={20} color={Colors.dark.error} />
            <ThemedText style={[styles.signOutText, { color: Colors.dark.error }]}>
              تسجيل الخروج
            </ThemedText>
          </Pressable>
        </View>

        <View style={styles.footer}>
          <ThemedText style={[styles.footerText, { color: theme.textTertiary }]}>
            صُنع بحب باستخدام الذكاء الاصطناعي
          </ThemedText>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: Spacing.lg,
  },
  profileCard: {
    alignItems: "center",
    marginBottom: Spacing["3xl"],
  },
  avatarContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.lg,
  },
  appName: {
    fontSize: 24,
    fontWeight: "700",
    marginBottom: Spacing.xs,
  },
  appTagline: {
    fontSize: 14,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: "600",
    textTransform: "uppercase",
    letterSpacing: 1,
    marginBottom: Spacing.md,
    marginLeft: Spacing.xs,
  },
  settingItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.sm,
  },
  settingIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: "500",
  },
  settingSubtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  footer: {
    alignItems: "center",
    paddingVertical: Spacing["2xl"],
  },
  footerText: {
    fontSize: 12,
  },
  signOutButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    gap: Spacing.sm,
  },
  signOutText: {
    fontSize: 16,
    fontWeight: "600",
  },
});
