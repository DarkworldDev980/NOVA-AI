import React, { useState, useCallback } from "react";
import {
  View,
  StyleSheet,
  FlatList,
  Pressable,
  Image,
  RefreshControl,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, { FadeInDown } from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";
import { Conversation } from "@/lib/supabase";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

const mockGroups: Conversation[] = [
  {
    id: "g1",
    type: "group",
    name: "Family Group",
    avatar_url: undefined,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    last_message: "See you all on Sunday!",
    last_message_at: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    unread_count: 5,
  },
  {
    id: "g2",
    type: "group",
    name: "Parents",
    avatar_url: undefined,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    last_message: "Happy anniversary!",
    last_message_at: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(),
    unread_count: 0,
  },
  {
    id: "g3",
    type: "group",
    name: "Siblings",
    avatar_url: undefined,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    last_message: "Who's coming to dinner?",
    last_message_at: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(),
    unread_count: 3,
  },
];

export default function GroupsScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const navigation = useNavigation<NavigationProp>();
  const { theme } = useTheme();

  const [groups, setGroups] = useState<Conversation[]>(mockGroups);
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setRefreshing(false);
  }, []);

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 1) return "Now";
    if (diffMins < 60) return `${diffMins}m`;
    if (diffHours < 24) return `${diffHours}h`;
    if (diffDays < 7) return `${diffDays}d`;
    return date.toLocaleDateString();
  };

  const renderGroup = ({ item, index }: { item: Conversation; index: number }) => (
    <Animated.View entering={FadeInDown.delay(index * 50).duration(300)}>
      <Pressable
        style={({ pressed }) => [
          styles.groupItem,
          { backgroundColor: pressed ? theme.backgroundSecondary : theme.backgroundDefault }
        ]}
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          navigation.navigate("Chat", { conversationId: item.id, name: item.name || "Group" });
        }}
        testID={`group-item-${item.id}`}
      >
        <View style={[styles.groupAvatar, { backgroundColor: Colors.light.primary + "20" }]}>
          <Feather name="users" size={24} color={Colors.light.primary} />
        </View>

        <View style={styles.groupContent}>
          <View style={styles.groupHeader}>
            <ThemedText type="h4" numberOfLines={1} style={styles.groupName}>
              {item.name}
            </ThemedText>
            <ThemedText style={[styles.timeText, { color: theme.textTertiary }]}>
              {item.last_message_at ? formatTime(item.last_message_at) : ""}
            </ThemedText>
          </View>
          <View style={styles.groupPreview}>
            <ThemedText numberOfLines={1} style={[styles.lastMessage, { color: theme.textSecondary }]}>
              {item.last_message || "No messages yet"}
            </ThemedText>
            {item.unread_count && item.unread_count > 0 ? (
              <View style={[styles.unreadBadge, { backgroundColor: Colors.light.primary }]}>
                <ThemedText style={styles.unreadText}>
                  {item.unread_count > 99 ? "99+" : item.unread_count}
                </ThemedText>
              </View>
            ) : null}
          </View>
        </View>
      </Pressable>
    </Animated.View>
  );

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <Image
        source={require("../../assets/images/empty-groups.png")}
        style={styles.emptyImage}
        resizeMode="contain"
      />
      <ThemedText type="h3" style={styles.emptyTitle}>
        No Groups Yet
      </ThemedText>
      <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
        Create your first family group to start chatting together
      </ThemedText>
      <Pressable
        style={[styles.createButton, { backgroundColor: Colors.light.primary }]}
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        }}
        testID="button-create-group"
      >
        <Feather name="plus" size={20} color="#FFFFFF" />
        <ThemedText style={styles.createButtonText}>Create Group</ThemedText>
      </Pressable>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <FlatList
        data={groups}
        renderItem={renderGroup}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.listContent,
          { 
            paddingTop: headerHeight + Spacing.xl,
            paddingBottom: tabBarHeight + Spacing.xl 
          }
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={Colors.light.primary}
          />
        }
        ListEmptyComponent={renderEmpty}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listContent: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.xs,
    flexGrow: 1,
  },
  groupItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
  },
  groupAvatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  groupContent: {
    flex: 1,
  },
  groupHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.xs,
  },
  groupName: {
    flex: 1,
    marginRight: Spacing.sm,
  },
  timeText: {
    fontSize: 12,
  },
  groupPreview: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  lastMessage: {
    flex: 1,
    fontSize: 14,
    marginRight: Spacing.sm,
  },
  unreadBadge: {
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 6,
  },
  unreadText: {
    color: "#FFFFFF",
    fontSize: 11,
    fontWeight: "600",
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing["5xl"],
  },
  emptyImage: {
    width: 180,
    height: 180,
    marginBottom: Spacing.xl,
  },
  emptyTitle: {
    marginBottom: Spacing.sm,
  },
  emptyText: {
    textAlign: "center",
    marginBottom: Spacing.xl,
    paddingHorizontal: Spacing.xl,
  },
  createButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.xl,
    borderRadius: BorderRadius.lg,
    gap: Spacing.sm,
  },
  createButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "600",
  },
});
