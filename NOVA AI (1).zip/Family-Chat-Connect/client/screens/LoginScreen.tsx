import React, { useState } from "react";
import {
  View,
  StyleSheet,
  TextInput,
  Pressable,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { useAuth } from "@/contexts/AuthContext";
import { Spacing, BorderRadius, Colors, CosmicGradient, Shadows } from "@/constants/theme";

type AuthMode = "login" | "signup";

export default function LoginScreen() {
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();
  const { signInWithGoogle, signInWithEmail, signUpWithEmail } = useAuth();

  const [mode, setMode] = useState<AuthMode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const handleEmailAuth = async () => {
    if (!email || !password) {
      setError("الرجاء ملء جميع الحقول");
      return;
    }

    if (mode === "signup" && password.length < 6) {
      setError("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
      return;
    }

    setLoading(true);
    setError("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    try {
      const result = mode === "login" 
        ? await signInWithEmail(email, password)
        : await signUpWithEmail(email, password, displayName);

      if (result.error) {
        setError(getErrorMessage(result.error.message));
      }
    } catch (err) {
      setError("حدث خطأ غير متوقع");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    setError("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    try {
      await signInWithGoogle();
    } catch (err) {
      setError("فشل تسجيل الدخول بـ Google");
    } finally {
      setGoogleLoading(false);
    }
  };

  const getErrorMessage = (errorMessage: string) => {
    const msg = errorMessage.toLowerCase();
    if (msg.includes("user not found") || msg.includes("invalid login")) return "البريد الإلكتروني أو كلمة المرور غير صحيحة";
    if (msg.includes("already registered") || msg.includes("already exists")) return "البريد الإلكتروني مستخدم مسبقاً";
    if (msg.includes("weak password") || msg.includes("at least 6")) return "كلمة المرور ضعيفة جداً (6 أحرف على الأقل)";
    if (msg.includes("invalid email")) return "البريد الإلكتروني غير صالح";
    if (msg.includes("email not confirmed")) return "يرجى تأكيد بريدك الإلكتروني";
    return "حدث خطأ في تسجيل الدخول";
  };

  return (
    <LinearGradient
      colors={CosmicGradient.colors as [string, string, ...string[]]}
      style={styles.container}
      start={CosmicGradient.start}
      end={CosmicGradient.end}
    >
      <KeyboardAvoidingView 
        style={styles.keyboardView}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <ScrollView
          contentContainerStyle={[
            styles.content,
            { 
              paddingTop: insets.top + Spacing["3xl"],
              paddingBottom: insets.bottom + Spacing["3xl"],
            }
          ]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.logoContainer}>
            <View style={[styles.logoIcon, { backgroundColor: Colors.dark.primary }]}>
              <Feather name="cpu" size={48} color="#FFFFFF" />
            </View>
            <ThemedText style={[styles.logoText, { color: theme.text }]}>
              NOVA AI
            </ThemedText>
            <ThemedText style={[styles.tagline, { color: theme.textSecondary }]}>
              مساعدك الذكي الشخصي
            </ThemedText>
          </View>

          <View style={styles.formContainer}>
            <Pressable
              style={[
                styles.googleButton,
                { 
                  backgroundColor: "#FFFFFF",
                  ...Shadows.medium,
                }
              ]}
              onPress={handleGoogleSignIn}
              disabled={googleLoading}
            >
              {googleLoading ? (
                <ActivityIndicator color="#4285F4" />
              ) : (
                <>
                  <View style={styles.googleIcon}>
                    <ThemedText style={styles.googleG}>G</ThemedText>
                  </View>
                  <ThemedText style={styles.googleButtonText}>
                    {mode === "login" ? "تسجيل الدخول بـ Google" : "إنشاء حساب بـ Google"}
                  </ThemedText>
                </>
              )}
            </Pressable>

            <View style={styles.divider}>
              <View style={[styles.dividerLine, { backgroundColor: theme.border }]} />
              <ThemedText style={[styles.dividerText, { color: theme.textTertiary }]}>
                أو
              </ThemedText>
              <View style={[styles.dividerLine, { backgroundColor: theme.border }]} />
            </View>

            <View style={styles.inputContainer}>
              {mode === "signup" && (
                <View style={[styles.inputWrapper, { backgroundColor: "rgba(255,255,255,0.1)" }]}>
                  <Feather name="user" size={20} color={theme.textSecondary} style={styles.inputIcon} />
                  <TextInput
                    style={[styles.input, { color: theme.text }]}
                    placeholder="الاسم (اختياري)"
                    placeholderTextColor={theme.textTertiary}
                    value={displayName}
                    onChangeText={setDisplayName}
                    autoCapitalize="words"
                    testID="input-name"
                  />
                </View>
              )}

              <View style={[styles.inputWrapper, { backgroundColor: "rgba(255,255,255,0.1)" }]}>
                <Feather name="mail" size={20} color={theme.textSecondary} style={styles.inputIcon} />
                <TextInput
                  style={[styles.input, { color: theme.text }]}
                  placeholder="البريد الإلكتروني"
                  placeholderTextColor={theme.textTertiary}
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoComplete="email"
                  testID="input-email"
                />
              </View>

              <View style={[styles.inputWrapper, { backgroundColor: "rgba(255,255,255,0.1)" }]}>
                <Feather name="lock" size={20} color={theme.textSecondary} style={styles.inputIcon} />
                <TextInput
                  style={[styles.input, { color: theme.text }]}
                  placeholder="كلمة المرور"
                  placeholderTextColor={theme.textTertiary}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                  autoComplete="password"
                  testID="input-password"
                />
                <Pressable onPress={() => setShowPassword(!showPassword)} style={styles.eyeIcon}>
                  <Feather 
                    name={showPassword ? "eye-off" : "eye"} 
                    size={20} 
                    color={theme.textSecondary} 
                  />
                </Pressable>
              </View>
            </View>

            {error ? (
              <View style={[styles.errorContainer, { backgroundColor: "rgba(239, 68, 68, 0.2)" }]}>
                <Feather name="alert-circle" size={16} color={Colors.dark.error} />
                <ThemedText style={[styles.errorText, { color: Colors.dark.error }]}>
                  {error}
                </ThemedText>
              </View>
            ) : null}

            <Pressable
              style={[
                styles.submitButton,
                { 
                  backgroundColor: Colors.dark.primary,
                  ...Shadows.glow,
                }
              ]}
              onPress={handleEmailAuth}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#FFFFFF" />
              ) : (
                <ThemedText style={styles.submitButtonText}>
                  {mode === "login" ? "تسجيل الدخول" : "إنشاء حساب"}
                </ThemedText>
              )}
            </Pressable>

            <Pressable
              style={styles.switchModeButton}
              onPress={() => {
                setMode(mode === "login" ? "signup" : "login");
                setError("");
              }}
            >
              <ThemedText style={[styles.switchModeText, { color: theme.textSecondary }]}>
                {mode === "login" ? "ليس لديك حساب؟ " : "لديك حساب بالفعل؟ "}
                <ThemedText style={{ color: Colors.dark.primary, fontWeight: "600" }}>
                  {mode === "login" ? "إنشاء حساب" : "تسجيل الدخول"}
                </ThemedText>
              </ThemedText>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  content: {
    flexGrow: 1,
    paddingHorizontal: Spacing.xl,
    justifyContent: "center",
  },
  logoContainer: {
    alignItems: "center",
    marginBottom: Spacing["4xl"],
  },
  logoIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.lg,
  },
  logoText: {
    fontSize: 36,
    fontWeight: "700",
    letterSpacing: 2,
  },
  tagline: {
    fontSize: 16,
    marginTop: Spacing.sm,
  },
  formContainer: {
    width: "100%",
    maxWidth: 400,
    alignSelf: "center",
  },
  googleButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: 52,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.lg,
  },
  googleIcon: {
    width: 24,
    height: 24,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  googleG: {
    fontSize: 18,
    fontWeight: "700",
    color: "#4285F4",
  },
  googleButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333333",
  },
  divider: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: Spacing.lg,
  },
  dividerLine: {
    flex: 1,
    height: 1,
  },
  dividerText: {
    paddingHorizontal: Spacing.md,
    fontSize: 14,
  },
  inputContainer: {
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    height: 52,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
  },
  inputIcon: {
    marginRight: Spacing.md,
  },
  input: {
    flex: 1,
    fontSize: 16,
    textAlign: "right",
  },
  eyeIcon: {
    padding: Spacing.sm,
  },
  errorContainer: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.md,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.md,
    gap: Spacing.sm,
  },
  errorText: {
    fontSize: 14,
    flex: 1,
    textAlign: "right",
  },
  submitButton: {
    height: 52,
    borderRadius: BorderRadius.md,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.lg,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  switchModeButton: {
    alignItems: "center",
    padding: Spacing.md,
  },
  switchModeText: {
    fontSize: 14,
  },
});
