import React, { useState, useCallback } from "react";
import {
  View,
  StyleSheet,
  SectionList,
  Pressable,
  Image,
  TextInput,
  RefreshControl,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useNavigation } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import Animated, { FadeInRight } from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";
import { Profile } from "@/lib/supabase";
import { RootStackParamList } from "@/navigation/RootStackNavigator";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;

const mockContacts: Profile[] = [
  { id: "1", display_name: "Ahmed", is_online: true, last_seen: new Date().toISOString(), created_at: new Date().toISOString() },
  { id: "2", display_name: "Ali", is_online: false, last_seen: new Date(Date.now() - 1000 * 60 * 30).toISOString(), created_at: new Date().toISOString() },
  { id: "3", display_name: "Dad", is_online: true, last_seen: new Date().toISOString(), created_at: new Date().toISOString() },
  { id: "4", display_name: "Fatima", is_online: false, last_seen: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), created_at: new Date().toISOString() },
  { id: "5", display_name: "Mom", is_online: true, last_seen: new Date().toISOString(), created_at: new Date().toISOString() },
  { id: "6", display_name: "Sara", is_online: false, last_seen: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), created_at: new Date().toISOString() },
];

interface Section {
  title: string;
  data: Profile[];
}

export default function ContactsScreen() {
  const insets = useSafeAreaInsets();
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const navigation = useNavigation<NavigationProp>();
  const { theme } = useTheme();

  const [contacts] = useState<Profile[]>(mockContacts);
  const [searchQuery, setSearchQuery] = useState("");
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setRefreshing(false);
  }, []);

  const filteredContacts = contacts.filter(contact =>
    contact.display_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sections: Section[] = filteredContacts
    .sort((a, b) => a.display_name.localeCompare(b.display_name))
    .reduce((acc: Section[], contact) => {
      const firstLetter = contact.display_name.charAt(0).toUpperCase();
      const existingSection = acc.find(section => section.title === firstLetter);
      if (existingSection) {
        existingSection.data.push(contact);
      } else {
        acc.push({ title: firstLetter, data: [contact] });
      }
      return acc;
    }, []);

  const formatLastSeen = (dateString: string, isOnline: boolean) => {
    if (isOnline) return "Online";
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));

    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return "Long time ago";
  };

  const renderContact = ({ item, index }: { item: Profile; index: number }) => (
    <Animated.View entering={FadeInRight.delay(index * 30).duration(200)}>
      <Pressable
        style={({ pressed }) => [
          styles.contactItem,
          { backgroundColor: pressed ? theme.backgroundSecondary : "transparent" }
        ]}
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          navigation.navigate("Chat", { conversationId: item.id, name: item.display_name });
        }}
        testID={`contact-item-${item.id}`}
      >
        <View style={styles.avatarContainer}>
          {item.avatar_url ? (
            <Image source={{ uri: item.avatar_url }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatarPlaceholder, { backgroundColor: Colors.light.primary + "20" }]}>
              <ThemedText style={[styles.avatarText, { color: Colors.light.primary }]}>
                {item.display_name.charAt(0).toUpperCase()}
              </ThemedText>
            </View>
          )}
          <View style={[
            styles.onlineIndicator, 
            { backgroundColor: item.is_online ? Colors.light.online : Colors.light.offline }
          ]} />
        </View>

        <View style={styles.contactContent}>
          <ThemedText type="h4" numberOfLines={1}>
            {item.display_name}
          </ThemedText>
          <ThemedText style={[styles.lastSeen, { color: item.is_online ? Colors.light.online : theme.textTertiary }]}>
            {formatLastSeen(item.last_seen, item.is_online)}
          </ThemedText>
        </View>

        <Pressable
          style={styles.chatButton}
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            navigation.navigate("Chat", { conversationId: item.id, name: item.display_name });
          }}
        >
          <Feather name="message-circle" size={20} color={Colors.light.primary} />
        </Pressable>
      </Pressable>
    </Animated.View>
  );

  const renderSectionHeader = ({ section }: { section: Section }) => (
    <View style={[styles.sectionHeader, { backgroundColor: theme.backgroundRoot }]}>
      <ThemedText style={[styles.sectionTitle, { color: Colors.light.primary }]}>
        {section.title}
      </ThemedText>
    </View>
  );

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <Image
        source={require("../../assets/images/empty-contacts.png")}
        style={styles.emptyImage}
        resizeMode="contain"
      />
      <ThemedText type="h3" style={styles.emptyTitle}>
        No Contacts Yet
      </ThemedText>
      <ThemedText style={[styles.emptyText, { color: theme.textSecondary }]}>
        Invite your family members to start chatting
      </ThemedText>
      <Pressable
        style={[styles.inviteButton, { backgroundColor: Colors.light.primary }]}
        onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)}
        testID="button-invite"
      >
        <Feather name="user-plus" size={20} color="#FFFFFF" />
        <ThemedText style={styles.inviteButtonText}>Invite Family</ThemedText>
      </Pressable>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      <View style={[styles.searchContainer, { paddingTop: headerHeight + Spacing.sm }]}>
        <View style={[styles.searchBar, { backgroundColor: theme.backgroundDefault }]}>
          <Feather name="search" size={18} color={theme.textTertiary} />
          <TextInput
            style={[styles.searchInput, { color: theme.text }]}
            placeholder="Search contacts..."
            placeholderTextColor={theme.textTertiary}
            value={searchQuery}
            onChangeText={setSearchQuery}
            testID="input-search"
          />
          {searchQuery.length > 0 ? (
            <Pressable onPress={() => setSearchQuery("")}>
              <Feather name="x" size={18} color={theme.textTertiary} />
            </Pressable>
          ) : null}
        </View>
      </View>

      <SectionList
        sections={sections}
        renderItem={renderContact}
        renderSectionHeader={renderSectionHeader}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.listContent,
          { paddingBottom: tabBarHeight + Spacing.xl }
        ]}
        showsVerticalScrollIndicator={false}
        stickySectionHeadersEnabled
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={Colors.light.primary}
          />
        }
        ListEmptyComponent={renderEmpty}
        scrollIndicatorInsets={{ bottom: insets.bottom }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  searchContainer: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.sm,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    height: 40,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.md,
    gap: Spacing.sm,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    height: "100%",
  },
  listContent: {
    paddingHorizontal: Spacing.lg,
    flexGrow: 1,
  },
  sectionHeader: {
    paddingVertical: Spacing.sm,
    paddingTop: Spacing.md,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: "600",
  },
  contactItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.sm,
  },
  avatarContainer: {
    position: "relative",
    marginRight: Spacing.md,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
  },
  avatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    fontSize: 18,
    fontWeight: "600",
  },
  onlineIndicator: {
    position: "absolute",
    bottom: 2,
    right: 2,
    width: 12,
    height: 12,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: "#FFFFFF",
  },
  contactContent: {
    flex: 1,
  },
  lastSeen: {
    fontSize: 13,
    marginTop: 2,
  },
  chatButton: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing["5xl"],
  },
  emptyImage: {
    width: 180,
    height: 180,
    marginBottom: Spacing.xl,
  },
  emptyTitle: {
    marginBottom: Spacing.sm,
  },
  emptyText: {
    textAlign: "center",
    marginBottom: Spacing.xl,
    paddingHorizontal: Spacing.xl,
  },
  inviteButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.xl,
    borderRadius: BorderRadius.lg,
    gap: Spacing.sm,
  },
  inviteButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "600",
  },
});
