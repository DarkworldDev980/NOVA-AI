import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useColorScheme as useSystemColorScheme } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Colors } from "@/constants/theme";

type ColorScheme = "light" | "dark";

interface ThemeContextType {
  theme: typeof Colors.light;
  isDark: boolean;
  colorScheme: ColorScheme;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const THEME_STORAGE_KEY = "@nova_theme";

export function ThemeProvider({ children }: { children: ReactNode }) {
  const systemColorScheme = useSystemColorScheme();
  const [colorScheme, setColorScheme] = useState<ColorScheme>("dark");
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(THEME_STORAGE_KEY).then((savedTheme) => {
      if (savedTheme === "light" || savedTheme === "dark") {
        setColorScheme(savedTheme);
      } else {
        setColorScheme("dark");
      }
      setIsLoaded(true);
    });
  }, []);

  const toggleTheme = () => {
    const newScheme = colorScheme === "dark" ? "light" : "dark";
    setColorScheme(newScheme);
    AsyncStorage.setItem(THEME_STORAGE_KEY, newScheme);
  };

  const isDark = colorScheme === "dark";
  const theme = Colors[colorScheme];

  const value = {
    theme,
    isDark,
    colorScheme,
    toggleTheme,
  };

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  
  if (context === undefined) {
    const systemScheme = "dark";
    return {
      theme: Colors[systemScheme],
      isDark: systemScheme === "dark",
      colorScheme: systemScheme as ColorScheme,
      toggleTheme: () => {},
    };
  }
  
  return context;
}
