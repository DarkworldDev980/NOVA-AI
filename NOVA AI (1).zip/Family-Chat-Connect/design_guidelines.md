# NOVA AI - Design Guidelines

## Brand Identity

**Purpose**: An intelligent AI assistant that helps users with questions, tasks, and creative work. Single-user focused with a premium, futuristic feel.

**Aesthetic Direction**: **Cosmic/Futuristic** - Deep space gradients, subtle particle effects, and a sophisticated sci-fi aesthetic. The app feels like conversing with advanced intelligence from the cosmos. Premium materials, restrained animations, and a sense of infinite possibility.

**Memorable Element**: Dynamic cosmic gradient background with subtle animated stars/particles that respond to AI responses, creating a living, breathing space environment.

## Navigation Architecture

**Root Navigation**: Stack-Only
- **Chat Screen** - Main conversation interface (root)
- **Settings Screen** - User preferences and profile

**Auth Required**: No (single-user, local storage)

## Screen-by-Screen Specifications

### Chat Screen (Root)
- **Custom transparent header**:
  - Left: Menu icon (opens Settings)
  - Center: "NOVA" wordmark in futuristic font
  - Right: New chat icon (clears conversation)
- **Layout**: Full-screen cosmic gradient background with subtle animated stars
  - Message list (inverted FlatList) - scrollable
  - Messages float over gradient
  - AI messages: Left-aligned, translucent dark surface with subtle glow
  - User messages: Right-aligned, accent gradient background
  - Floating input area at bottom: Text input + voice icon + send button with glow effect
- **Safe area**: top (headerHeight + Spacing.xl), bottom (insets.bottom + Spacing.xl)
- **Empty state**: Centered welcome card with NOVA logo, suggested prompts as tappable chips
- **RTL Support**: Flip message alignment and icons for Arabic

### Settings Screen (Stack)
- **Default header**: "Settings" title, back button (left)
- **ScrollView sections**:
  1. Profile card: Avatar (cosmic-themed preset), display name field, "Cosmic Explorer" subtitle
  2. Preferences: Language (English/العربية toggle), Theme (Auto/Light/Dark/Cosmic), Voice Input toggle
  3. About: App version, Privacy Policy, Terms of Service (placeholder links)
- **Safe area**: top (Spacing.xl), bottom (insets.bottom + Spacing.xl)

## Color Palette

- **Primary**: #8B5CF6 (Vibrant cosmic purple - AI intelligence)
- **Primary Variant**: #7C3AED (Pressed state)
- **Accent**: #3B82F6 (Electric blue - highlights)
- **Background**: Linear gradient (#0F172A → #1E1B4B) (Deep space)
- **Surface**: rgba(30, 27, 75, 0.6) (Translucent dark with blur effect)
- **Surface Variant**: rgba(139, 92, 246, 0.1) (Subtle purple tint for AI messages)
- **Text Primary**: #F8FAFC (Off-white for dark backgrounds)
- **Text Secondary**: #CBD5E1 (Light gray)
- **Text Tertiary**: #64748B (Muted)
- **Glow**: rgba(139, 92, 246, 0.3) (Purple glow for buttons/AI responses)
- **Stars**: rgba(248, 250, 252, 0.6) (Twinkling particles)

## Typography

**Font**: Orbitron (Google Font - futuristic, tech-forward) for headings, Inter (system fallback) for body
- **H1**: Orbitron Bold, 28px (NOVA title)
- **H2**: Orbitron SemiBold, 22px
- **H3**: Orbitron Medium, 18px
- **Body**: Inter Regular, 16px (messages, readable at small sizes)
- **Caption**: Inter Regular, 14px
- **Small**: Inter Regular, 12px

## Visual Design

- **Border Radius**: Medium-large (12px cards, 18px message bubbles, 24px input field)
- **Shadows**: Glowing effect for floating input (shadowColor: #8B5CF6, shadowOpacity: 0.3, shadowRadius: 8)
- **Icons**: Feather icons
- **Message Style**: AI messages have subtle left border (2px, Primary color) as accent
- **Backdrop**: Use blur effect (BlurView) for surface elements over gradient
- **Spacing**: xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32
- **RTL**: Ensure all text alignment, icons, and message bubbles flip for Arabic

## Assets to Generate

1. **icon.png** - Geometric AI brain/star constellation in purple gradient - USED: Device home screen
2. **splash-icon.png** - NOVA wordmark with cosmic glow - USED: Launch screen
3. **empty-chat.png** - Minimalist cosmic orb with orbiting particles - USED: Chat screen empty state
4. **avatar-cosmic.png** - Abstract galaxy/nebula avatar preset - USED: Settings profile, default avatar
5. **welcome-illustration.png** - Subtle constellation pattern forming AI symbol - USED: Chat screen initial welcome card
6. **stars-pattern.png** - Seamless star field texture (low opacity) - USED: Chat screen background overlay